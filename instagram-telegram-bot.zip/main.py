import asyncio
import html
import io
import os
import re
import unicodedata
from html.parser import HTMLParser
from urllib.parse import urlparse

import httpx
from fastapi import BackgroundTasks, FastAPI, Header, HTTPException, Request
from openpyxl import Workbook
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas

app = FastAPI(title="Instagram Following Checker")
BOT_TOKEN = os.getenv("TG_BOT_TOKEN", "")
WEBHOOK_SECRET = os.getenv("WEBHOOK_SECRET", "")
ALLOWED_USER_ID = os.getenv("TG_ALLOWED_USER_ID", "")
API = f"https://api.telegram.org/bot{BOT_TOKEN}"
# In-memory by design: Render restarts clear pending uploads.
state = {}


def normalize_username(value: str) -> str:
    """Canonical case-insensitive key; preserves no display casing."""
    return unicodedata.normalize("NFKC", value.strip().lstrip("@")).casefold()


class InstagramParser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.usernames = set()

    def handle_starttag(self, tag, attrs):
        if tag.lower() != "a":
            return
        href = dict(attrs).get("href", "")
        try:
            parts = [p for p in urlparse(html.unescape(href)).path.split("/") if p]
        except ValueError:
            return
        if not parts:
            return
        candidate = parts[0].lstrip("@")
        key = normalize_username(candidate)
        if key and re.fullmatch(r"[\w.]+", candidate, flags=re.UNICODE):
            self.usernames.add(candidate)


def parse_instagram_html(content: bytes | str) -> dict[str, str]:
    parser = InstagramParser()
    if isinstance(content, bytes):
        content = content.decode("utf-8", errors="replace")
    parser.feed(content)
    # Keep the first encountered spelling as canonical display capitalization.
    by_key = {}
    for name in parser.usernames:
        by_key.setdefault(normalize_username(name), name)
    return by_key


def non_followers(following: dict[str, str], followers: dict[str, str]) -> list[str]:
    follower_keys = {normalize_username(name) for name in followers.values()}
    # Keep following-list canonical spelling and deduplicate case variants.
    result = {}
    for name in following.values():
        key = normalize_username(name)
        if key and key not in follower_keys:
            result.setdefault(key, name)
    return sorted(result.values(), key=str.casefold)


async def telegram(method: str, data=None, files=None):
    if not BOT_TOKEN:
        raise RuntimeError("TG_BOT_TOKEN is not configured")
    async with httpx.AsyncClient(timeout=60) as client:
        response = await client.post(f"{API}/{method}", data=data, files=files)
        response.raise_for_status()
        payload = response.json()
        if not payload.get("ok"):
            raise RuntimeError(f"Telegram API error: {payload}")
        return payload["result"]


async def send_text(chat_id: int, text: str):
    await telegram("sendMessage", {"chat_id": chat_id, "text": text})


async def download_file(file_id: str) -> bytes:
    info = await telegram("getFile", {"file_id": file_id})
    async with httpx.AsyncClient(timeout=60) as client:
        response = await client.get(f"https://api.telegram.org/file/bot{BOT_TOKEN}/{info['file_path']}")
        response.raise_for_status()
        return response.content


def make_excel(names):
    wb = Workbook()
    ws = wb.active
    ws.title = "Not following back"
    ws.append(["Username", "Profile link"])
    for name in names:
        ws.append([name, f"https://www.instagram.com/{name}/"])
    stream = io.BytesIO()
    wb.save(stream)
    stream.seek(0)
    return stream


def make_pdf(names):
    stream = io.BytesIO()
    pdf = canvas.Canvas(stream, pagesize=A4)
    width, height = A4
    pdf.setTitle("Instagram non-followers")
    pdf.setFont("Helvetica-Bold", 15)
    pdf.drawString(48, height - 48, "Accounts not following you back")
    pdf.setFont("Helvetica", 10)
    y = height - 76
    for name in names:
        if y < 45:
            pdf.showPage(); pdf.setFont("Helvetica", 10); y = height - 45
        pdf.drawString(48, y, f"{name}  https://www.instagram.com/{name}/")
        y -= 16
    pdf.save()
    stream.seek(0)
    return stream


async def send_document(chat_id, filename, content, caption):
    await telegram("sendDocument", {"chat_id": chat_id, "caption": caption},
                   {"document": (filename, content, "application/octet-stream")})


async def process_upload(chat_id: int, kind: str, file_id: str):
    try:
        raw = await download_file(file_id)
        parsed = parse_instagram_html(raw)
        state.setdefault(chat_id, {})[kind] = parsed
        current = state[chat_id]
        if "following" not in current or "followers" not in current:
            await send_text(chat_id, f"تم استلام ملف {kind}. أرسل الملف الآخر أيضاً.")
            return
        names = non_followers(current["following"], current["followers"])
        await send_text(chat_id, f"اكتمل التحليل: {len(names)} حساباً لا يتابعونك بالمقابل.")
        lines = "\n".join(f"@{n}  https://www.instagram.com/{n}/" for n in names) or "لا توجد حسابات."
        await send_text(chat_id, lines[:4000])
        await send_document(chat_id, "non_followers.xlsx", make_excel(names).getvalue(), "Excel list")
        await send_document(chat_id, "non_followers.pdf", make_pdf(names).getvalue(), "PDF list")
        state.pop(chat_id, None)
    except Exception as exc:
        await send_text(chat_id, f"خطا در پردازش فایل: {str(exc)[:300]}")


@app.get("/")
async def health():
    return {"status": "ok"}


@app.post("/telegram/webhook")
async def webhook(request: Request, background_tasks: BackgroundTasks,
                  x_telegram_bot_api_secret_token: str | None = Header(default=None)):
    if not WEBHOOK_SECRET or x_telegram_bot_api_secret_token != WEBHOOK_SECRET:
        raise HTTPException(status_code=403, detail="Invalid webhook secret")
    update = await request.json()
    message = update.get("message", {})
    sender = message.get("from", {})
    chat_id = message.get("chat", {}).get("id")
    if not chat_id:
        return {"ok": True}
    if ALLOWED_USER_ID and str(sender.get("id")) != ALLOWED_USER_ID:
        background_tasks.add_task(send_text, chat_id, "این ربات خصوصی است.")
        return {"ok": True}
    text = message.get("text", "")
    if text.startswith("/start"):
        background_tasks.add_task(send_text, chat_id, "فایل‌های following.html و followers_1.html را ارسال کنید. برای شناسه: /id")
    elif text.startswith("/id"):
        background_tasks.add_task(send_text, chat_id, f"شناسه تلگرام شما: {sender.get('id', 'نامشخص')}")
    elif text.startswith("/reset"):
        state.pop(chat_id, None)
        background_tasks.add_task(send_text, chat_id, "وضعیت پاک شد.")
    elif message.get("document"):
        doc = message["document"]
        filename = doc.get("file_name", "").lower()
        if filename.endswith("following.html"):
            kind = "following"
        elif filename.endswith("followers_1.html"):
            kind = "followers"
        else:
            background_tasks.add_task(send_text, chat_id, "فقط following.html یا followers_1.html قابل قبول است.")
            return {"ok": True}
        background_tasks.add_task(process_upload, chat_id, kind, doc["file_id"])
    else:
        background_tasks.add_task(send_text, chat_id, "دو فایل following.html و followers_1.html را ارسال کنید.")
    return {"ok": True}
