# Instagram–Telegram Following Checker

این ربات فایل‌های رسمی خروجی اینستاگرام را تحلیل می‌کند؛ رمز اینستاگرام نمی‌خواهد و آنفالو خودکار انجام نمی‌دهد. برای تحلیل هر دو فایل `following.html` و `followers_1.html` را در تلگرام بفرستید. فهرست حساب‌هایی که شما دنبال می‌کنید ولی شما را دنبال نمی‌کنند، با لینک مستقیم، در پیام و فایل‌های Excel و PDF برمی‌گردد. اطلاعات موقت در حافظه است و با restart سرویس پاک می‌شود.

## فارسی: راه‌اندازی از گوشی

### ۱. بارگذاری فایل‌ها در GitHub
1. در مخزن خصوصی `instagram-telegram-bot` وارد صفحه اصلی شوید.
2. روی **Add file** و سپس **Upload files** بزنید.
3. سه فایل `main.py`، `requirements.txt` و `README.md` را انتخاب و بارگذاری کنید. این ZIP را می‌توانید در گوشی باز کنید و فایل‌ها را انتخاب کنید.
4. پایین صفحه **Commit changes** را بزنید.

### ۲. ساخت سرویس Render
1. در Render وارد حساب شوید و **New +** سپس **Web Service** را انتخاب کنید.
2. مخزن GitHub را وصل کنید و `instagram-telegram-bot` را انتخاب کنید.
3. تنظیمات: **Runtime: Python**، **Build Command:** `pip install -r requirements.txt`، **Start Command:** `uvicorn main:app --host 0.0.0.0 --port $PORT`.
4. در بخش **Environment**، متغیرهای زیر را اضافه کنید:
   - `PYTHON_VERSION` = `3.12.0`
   - `TG_BOT_TOKEN` = توکن ربات از `@BotFather`
   - `WEBHOOK_SECRET` = یک مقدار تصادفی طولانی (حروف و عدد؛ بدون فاصله)
   - `TG_ALLOWED_USER_ID` = شناسه عددی تلگرام شما
5. **Create Web Service** را بزنید و منتظر پایان Deploy بمانید. آدرس سرویس شبیه `https://your-service.onrender.com` خواهد بود.

### ۳. شناسه و تنظیم webhook
برای گرفتن شناسه عددی، ابتدا webhook را تنظیم کنید، سپس در تلگرام به ربات `/id` بفرستید. برای تنظیم webhook، در مرورگر گوشی این نشانی را باز کنید، جای‌نگهدارها را با مقادیر خود عوض کنید:

`https://api.telegram.org/bot<TG_BOT_TOKEN>/setWebhook?url=https://<RENDER_SERVICE>.onrender.com/telegram/webhook&secret_token=<WEBHOOK_SECRET>`

پاسخ باید شامل `"ok":true` باشد. حالا `/id` را برای ربات بفرستید. مقدار عددی را در `TG_ALLOWED_USER_ID` در Render وارد کنید و سرویس را از **Manual Deploy > Deploy latest commit** دوباره منتشر کنید. اگر از قبل شناسه خود را می‌دانید، آن را همان ابتدا وارد کنید.

### ۴. آزمایش
- باز کردن `https://<RENDER_SERVICE>.onrender.com/` باید `{"status":"ok"}` نشان دهد.
- در تلگرام `/start` و سپس `/id` را بفرستید.
- از بخش Download information اینستاگرام، دو فایل HTML نام‌برده را دریافت کنید و به صورت **Document/File** (نه عکس) برای ربات بفرستید.
- پس از دریافت هر دو، تعداد و لینک‌ها و دو پیوست `non_followers.xlsx` و `non_followers.pdf` ارسال می‌شوند. برای شروع دوباره `/reset` بفرستید.

**نکته Render رایگان:** سرویس ممکن است پس از مدتی بی‌کاری متوقف شود و در شروع مجدد حافظه موقت خالی خواهد شد. اگر webhook تنظیم مجدد شد، همان نشانی `setWebhook` را دوباره باز کنید. فایل‌ها را برای حفظ حریم خصوصی فقط به ربات خصوصی خودتان ارسال کنید.

## English: setup

1. In the private GitHub repository, use **Add file > Upload files** to upload `main.py`, `requirements.txt`, and `README.md`; commit the upload.
2. In Render choose **New + > Web Service**, connect the repository, select Python, set build command to `pip install -r requirements.txt`, and start command to `uvicorn main:app --host 0.0.0.0 --port $PORT`.
3. Add environment variables: `PYTHON_VERSION=3.12.0`, `TG_BOT_TOKEN` (from BotFather), a long random `WEBHOOK_SECRET`, and numeric `TG_ALLOWED_USER_ID` (your Telegram user ID). Deploy.
4. Set the webhook by opening this URL in a browser, replacing placeholders (URL-encode token/secret if needed):

   `https://api.telegram.org/bot<TG_BOT_TOKEN>/setWebhook?url=https://<RENDER_SERVICE>.onrender.com/telegram/webhook&secret_token=<WEBHOOK_SECRET>`

   Confirm `"ok":true`. Send `/id` to the bot; set that numeric ID as `TG_ALLOWED_USER_ID` in Render and redeploy. If you already know your ID, configure it before the first deploy.
5. Check the service root returns `{"status":"ok"}`. Send `/start`, `/id`, then upload both Instagram export files as documents. The bot returns direct profile links and Excel/PDF attachments. `/reset` clears the current in-memory upload state.

The bot never asks for your Instagram password and does not unfollow anyone. Temporary state is in memory and is cleared on service restart. The webhook endpoint requires Telegram's secret-token header.
